# 💞 LoveChat — a WhatsApp-style private chat for couples

A single Node.js server + tiny vanilla-JS frontend. No build step.

## Run it

```bash
npm install
npm start        # → http://localhost:8080
```

Set `PORT=3000 npm start` to change the port. Data persists to `data/db.json`.

## How it works

1. **Sign up** with your name, email, and password (this is the gate — nobody gets in without an account).
2. You land on a **"send this link to your person"** screen with your unique invite link/code.
3. Your partner opens the link from anywhere in the world, **signs up with their own email + password**, and your private 1-on-1 chat opens for both of you instantly.
4. Already have an account and got a link? Just sign in and tap **Accept this invite**.

Only two people can ever share a LoveChat.

## Features

**WhatsApp-style core**
- Familiar WhatsApp look & feel (no status tab, no clutter — just the chat)
- Real-time messaging over WebSocket, with a polling fallback
- ✓ sent / ✓✓ delivered / blue ✓✓ read ticks
- *typing…* indicator, **online** / **last seen** status
- Date dividers, chat wallpaper, mobile layout with slide-in chat
- Email + password sign-up & sign-in (scrypt-hashed passwords, token sessions)

**Little extras for the two of you**
- 💞 Days-together counter + anniversary countdown
- 🕰 **Memory Lane** — surfaces an old message from "on this day"
- 💗 Tap any message to **react** (❤️ 😂 😮 😢 🙏 👍) or delete it for yourself
- 💥 Heart burst when someone says "I love you"
- 📊 Love stats: level, message counts, your first message
- 📝 A secret note only the two of you can see
- 🎨 4 shared wallpapers, dark mode, sounds (on/off)

## Deploying anywhere

Any Node 18+ host works: Render, Railway, Fly.io, a VPS, etc.
- Build command: `npm install`
- Start command: `npm start`
- It's fully stateless in code — keep `data/` on a persistent disk, or run a single instance so the JSON store stays consistent.
- For HTTPS (needed for `wss://`), put it behind any TLS proxy (Render/Fly give you one automatically).
