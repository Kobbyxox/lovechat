/* LoveChat — client */
'use strict';

const $ = (s) => document.querySelector(s);
const $$ = (s) => Array.from(document.querySelectorAll(s));

const EMOJIS = ['❤️', '🥰', '😘', '😍', '😂', '😭', '😮', '😳', '🥺', '🙏', '👍', '🔥', '✨', '💖', '💘', '😎', '😴', '🎉'];
const LOVE_NAMES = ['Just met', 'Crushing', 'Smitten', 'Head over heels', 'In deep', 'Soulmates', 'Destiny', 'Unbreakable', 'Written in the stars', 'Forever'];
const LOVE_RE = /\b(i love you|love you|love u|te amo|mi vida|my heart is yours|you are my world|❤️|💖|💘)\b/i;

const state = {
  token: localStorage.getItem('lc_token') || null,
  me: null, partner: null, couple: null,
  msgs: [], msgById: new Map(),
  typing: false, typingTimer: null,
  partnerOnline: false, partnerLastSeen: 0,
  unread: 0, chatOpen: false,
  ws: null, wsRetrying: false,
  pollTimer: null, waitTimer: null,
  lastTypingSent: 0,
  pendingInvite: localStorage.getItem('lc_invite') || null,
  lastMemoryShown: localStorage.getItem('lc_memory') || '',
  memoryEl: null,
};

const msgsEl = $('#msgs');

// ---------------- utils ----------------
function el(tag, cls, text) {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (text != null) n.textContent = text;
  return n;
}
const timeFmt = new Intl.DateTimeFormat(undefined, { hour: 'numeric', minute: '2-digit' });
const dayFmt = new Intl.DateTimeFormat(undefined, { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' });
const shortDayFmt = new Intl.DateTimeFormat(undefined, { month: 'long', day: 'numeric' });
const fmtTime = (ts) => timeFmt.format(new Date(ts));
function fmtDay(ts) {
  const d = new Date(ts), now = new Date();
  const startOf = (x) => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
  const diff = (startOf(now) - startOf(d)) / 86400000;
  if (diff === 0) return 'Today';
  if (diff === 1) return 'Yesterday';
  if (diff < 7) return d.toLocaleDateString(undefined, { weekday: 'long' });
  return dayFmt.format(d);
}
function daysTogether() {
  if (!state.couple) return 0;
  return Math.max(1, Math.floor((Date.now() - state.couple.startTs) / 86400000));
}
function anniversaryText() {
  if (!state.couple) return '—';
  const s = new Date(state.couple.startTs);
  const now = new Date();
  const next = new Date(now.getFullYear(), s.getMonth(), s.getDate());
  if (next < new Date(now.getFullYear(), now.getMonth(), now.getDate())) next.setFullYear(now.getFullYear() + 1);
  const left = Math.round((next - new Date(now.getFullYear(), now.getMonth(), now.getDate())) / 86400000);
  if (left === 0) return 'today! 🎉';
  const months = Math.max(1, Math.round(left / 30.44));
  return `in ${months} month${months > 1 ? 's' : ''}`;
}
function loveLevel() {
  const total = state.msgs.length;
  const lvl = Math.min(10, 1 + Math.floor(Math.sqrt(total / 8)));
  return { lvl, name: LOVE_NAMES[lvl - 1], pct: ((lvl - 1 + (Math.sqrt(total / 8) % 1)) / 10) * 100 };
}
const soundOn = () => localStorage.getItem('lc_sound') !== 'off';
const isDesktop = () => window.matchMedia('(min-width: 761px)').matches;
const chatVisible = () => isDesktop() || $('#app-shell').classList.contains('show-chat');

function toast(msg, ms = 2600) {
  const t = el('div', 'toast', msg);
  $('#toasts').appendChild(t);
  setTimeout(() => t.remove(), ms);
}
function copyText(text) {
  const done = () => toast('Link copied — send it to your person 💌');
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text).then(done).catch(() => fallbackCopy(text, done));
  } else fallbackCopy(text, done);
}
function fallbackCopy(text, done) {
  const ta = document.createElement('textarea');
  ta.value = text;
  document.body.appendChild(ta);
  ta.select();
  try { document.execCommand('copy'); done(); } catch { toast('Copy the link manually from the box'); }
  ta.remove();
}
const inviteLink = () => `${location.origin}/?invite=${state.me ? state.me.inviteCode : ''}`;

// ---------------- audio ----------------
let audioCtx = null;
function blip(freqs, dur = 0.09, gain = 0.05) {
  if (!soundOn()) return;
  try {
    audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
    if (audioCtx.state === 'suspended') audioCtx.resume();
    const t = audioCtx.currentTime;
    freqs.forEach((f, i) => {
      const o = audioCtx.createOscillator();
      const g = audioCtx.createGain();
      o.type = 'sine';
      o.frequency.value = f;
      g.gain.setValueAtTime(gain, t + i * dur);
      g.gain.exponentialRampToValueAtTime(0.001, t + (i + 1) * dur);
      o.connect(g); g.connect(audioCtx.destination);
      o.start(t + i * dur);
      o.stop(t + (i + 1) * dur + 0.03);
    });
  } catch { /* audio not available */ }
}
document.addEventListener('pointerdown', () => {
  try { if (audioCtx && audioCtx.state === 'suspended') audioCtx.resume(); } catch { /* ignore */ }
}, { once: true });

function heartBurst() {
  const box = $('#hearts');
  for (let i = 0; i < 14; i++) {
    const s = el('span', null, ['❤️', '💖', '💘', '💕', '✨'][Math.floor(Math.random() * 5)]);
    s.style.left = Math.random() * 100 + 'vw';
    s.style.fontSize = 16 + Math.random() * 28 + 'px';
    s.style.animationDelay = Math.random() * 0.5 + 's';
    box.appendChild(s);
    setTimeout(() => s.remove(), 3200);
  }
}

// ---------------- api ----------------
async function api(path, opts = {}) {
  const res = await fetch(path, {
    method: opts.method || (opts.body ? 'POST' : 'GET'),
    headers: {
      'Content-Type': 'application/json',
      ...(state.token ? { Authorization: 'Bearer ' + state.token } : {}),
    },
    body: opts.body ? JSON.stringify(opts.body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Something went wrong.');
  return data;
}

// ---------------- screens ----------------
function show(name) {
  ['auth', 'waiting', 'app'].forEach((s) => $('#screen-' + s).classList.toggle('hidden', s !== name));
}

// ---------------- auth ----------------
function setAuthError(msg) { $('#auth-error').textContent = msg || ''; }
function setTab(which) {
  $('#tab-login').classList.toggle('active', which === 'login');
  $('#tab-signup').classList.toggle('active', which === 'signup');
  $('#form-login').classList.toggle('hidden', which !== 'login');
  $('#form-signup').classList.toggle('hidden', which !== 'signup');
  setAuthError('');
}
$('#tab-login').onclick = () => setTab('login');
$('#tab-signup').onclick = () => setTab('signup');

$('#form-login').onsubmit = async (e) => {
  e.preventDefault();
  const btn = e.target.querySelector('button');
  btn.disabled = true;
  try {
    const data = await api('/api/login', { body: { email: $('#li-email').value, password: $('#li-pass').value } });
    await onAuth(data);
  } catch (err) { setAuthError(err.message); }
  btn.disabled = false;
};
$('#form-signup').onsubmit = async (e) => {
  e.preventDefault();
  const btn = e.target.querySelector('button');
  btn.disabled = true;
  try {
    const data = await api('/api/signup', {
      body: {
        name: $('#su-name').value,
        email: $('#su-email').value,
        password: $('#su-pass').value,
        invite: state.pendingInvite || undefined,
      },
    });
    await onAuth(data);
  } catch (err) { setAuthError(err.message); }
  btn.disabled = false;
};

async function onAuth(data) {
  state.token = data.token;
  localStorage.setItem('lc_token', data.token);
  state.me = data.me;
  if (data.couple) {
    localStorage.removeItem('lc_invite');
    state.pendingInvite = null;
    await startApp();
  } else {
    await showWaiting();
  }
}

// ---------------- waiting screen ----------------
function showWaiting() {
  show('waiting');
  $('#wait-hi').textContent = `You're all set, ${state.me.name}!`;
  $('#wait-link').textContent = inviteLink();
  $('#wait-code').textContent = state.me.inviteCode;
  $('#invite-accept-row').classList.toggle('hidden', !state.pendingInvite);
  clearInterval(state.waitTimer);
  state.waitTimer = setInterval(async () => {
    try {
      const c = await api('/api/couple');
      if (c.couple) {
        clearInterval(state.waitTimer);
        localStorage.removeItem('lc_invite');
        state.pendingInvite = null;
        toast('Your person just joined! 💘');
        heartBurst();
        await startApp();
      }
    } catch { /* retry next tick */ }
  }, 2500);
}
$('#copy-link').onclick = () => copyText(inviteLink());
$('#tb-link').onclick = () => copyText(inviteLink());
$('#accept-invite').onclick = async () => {
  try {
    const r = await api('/api/invite', { body: { code: state.pendingInvite } });
    localStorage.removeItem('lc_invite');
    state.pendingInvite = null;
    toast('You joined the chat! 💘');
    heartBurst();
    await startApp();
  } catch (err) { toast(err.message); }
};
$('#logout-wait').onclick = doLogout;

// ---------------- app ----------------
async function startApp() {
  const meRes = await api('/api/me');
  state.me = meRes.me;
  state.partner = meRes.partner;
  state.couple = meRes.couple;
  if (!state.couple) { showWaiting(); return; }
  const c = await api('/api/couple');
  state.unread = c.unread;
  state.partnerOnline = c.partnerOnline;
  state.partnerLastSeen = state.partner ? state.partner.lastSeen : 0;

  show('app');
  applyTheme();
  applyWallpaper(state.couple.wallpaper);
  renderSide();
  openChat();
  connectWS();
  startPolling();
  maybeMemoryLane();
}

function renderSide() {
  const m = state.me, p = state.partner;
  if (!m) return;
  $('#me-av').textContent = m.name[0].toUpperCase();
  $('#me-name').textContent = m.name;
  $('#me-sub').textContent = p ? `❤ chatting with ${p.name}` : 'waiting for your person…';
  if (p) {
    $('#partner-av').textContent = p.name[0].toUpperCase();
    $('#partner-name').textContent = p.name;
    $('#chat-av').textContent = p.name[0].toUpperCase();
    $('#chat-name').textContent = p.name;
  }
  $('#days-pill').textContent = `💞 ${daysTogether()} day${daysTogether() > 1 ? 's' : ''} of us · anniversary ${anniversaryText()}`;
  renderPreview();
  renderBadge();
}

function renderPreview() {
  const last = state.msgs[state.msgs.length - 1];
  if (!last) {
    $('#chat-preview').textContent = state.typing ? 'typing…' : 'Say hi 💌';
    $('#chat-time').textContent = '';
    return;
  }
  $('#chat-preview').textContent = (last.from === state.me.id ? 'You: ' : '') + last.text;
  $('#chat-time').textContent = fmtTime(last.ts);
  if (state.typing) $('#chat-preview').textContent = 'typing…';
}
function renderBadge() {
  const b = $('#chat-badge');
  b.classList.toggle('hidden', state.unread <= 0);
  b.textContent = state.unread > 99 ? '99+' : state.unread;
}
function renderStatus() {
  const s = $('#chat-status');
  s.classList.toggle('typing', state.typing);
  if (state.typing) { s.textContent = 'typing…'; return; }
  if (state.partnerOnline) { s.textContent = 'online'; return; }
  const ts = state.partnerLastSeen;
  if (!ts) { s.textContent = 'new to LoveChat'; return; }
  const diff = Date.now() - ts;
  const d = new Date(ts), now = new Date();
  const startOf = (x) => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
  if (diff < 60000) s.textContent = 'last seen just now';
  else if (diff < 3600000) s.textContent = `last seen ${Math.floor(diff / 60000)} min ago`;
  else if (startOf(d) === startOf(now)) s.textContent = `last seen today at ${fmtTime(ts)}`;
  else if (startOf(now) - startOf(d) === 86400000) s.textContent = `last seen yesterday at ${fmtTime(ts)}`;
  else s.textContent = `last seen ${shortDayFmt.format(d)}`;
}

// ---------------- messages rendering ----------------
function checksFor(m) {
  if (m.from !== state.me.id || !state.partner) return '';
  if (m.readBy.includes(state.partner.id)) return '<span class="ticks read">✓✓</span>';
  if (m.delivered) return '<span class="ticks">✓✓</span>';
  return '<span class="ticks">✓</span>';
}
function bubbleNode(m, prev) {
  const wrap = el('div', 'msg' + (m.from === state.me.id ? ' self' : '') + (!prev || prev.from !== m.from || m.ts - prev.ts > 300000 ? ' first' : ''));
  const bub = el('div', 'bubble');
  bub.dataset.mid = m.id;
  const txt = el('span', 'bubble-text', m.text);
  bub.appendChild(txt);
  const meta = el('span', 'bubble-meta');
  meta.innerHTML = fmtTime(m.ts) + checksFor(m);
  bub.appendChild(meta);
  const rx = el('div', 'reactions');
  for (const [emoji, ids] of Object.entries(m.reactions)) {
    const c = el('span', 'react-chip' + (ids.includes(state.me.id) ? ' mine' : ''), `${emoji}${ids.length > 1 ? ' ' + ids.length : ''}`);
    rx.appendChild(c);
  }
  if (rx.children.length) bub.appendChild(rx);
  wrap.appendChild(bub);
  return wrap;
}
function renderMsgs() {
  msgsEl.innerHTML = '';
  let lastDay = '', prev = null;
  for (const m of state.msgs) {
    const day = fmtDay(m.ts);
    if (day !== lastDay) {
      msgsEl.appendChild(el('div', 'day-chip', day));
      lastDay = day;
      prev = null;
    }
    msgsEl.appendChild(bubbleNode(m, prev));
    prev = m;
  }
  scrollBottom(true);
}
function upsertMsg(m, { silent = false } = {}) {
  const existing = state.msgById.get(m.id);
  if (existing) {
    Object.assign(existing, m);
    const node = msgsEl.querySelector(`.bubble[data-mid="${m.id}"]`);
    if (node) {
      node.querySelector('.bubble-meta').innerHTML = fmtTime(m.ts) + checksFor(m);
      const rx = el('div', 'reactions');
      for (const [emoji, ids] of Object.entries(m.reactions)) {
        rx.appendChild(el('span', 'react-chip' + (ids.includes(state.me.id) ? ' mine' : ''), `${emoji}${ids.length > 1 ? ' ' + ids.length : ''}`));
      }
      const oldRx = node.querySelector('.reactions');
      if (rx.children.length) { if (oldRx) oldRx.replaceWith(rx); else node.appendChild(rx); }
      else if (oldRx) oldRx.remove();
    }
    renderPreview();
    return;
  }
  state.msgs.push(m);
  state.msgById.set(m.id, m);
  state.msgs.sort((a, b) => a.ts - b.ts);
  const prev = state.msgs[state.msgs.indexOf(m) - 1];
  let day = fmtDay(m.ts);
  let lastChild = msgsEl.lastElementChild;
  if (!lastChild || !lastChild.classList.contains('day-chip') || lastChild.textContent !== day) {
    msgsEl.appendChild(el('div', 'day-chip', day));
  }
  msgsEl.appendChild(bubbleNode(m, prev));
  renderPreview();
  renderBadge();
  if (m.from === state.me.id) {
    blip([740], 0.06, 0.03);
    scrollBottom(false);
  } else {
    if (LOVE_RE.test(m.text)) heartBurst();
    if (chatVisible()) {
      markRead(m.id);
      blip([587, 880]);
      scrollBottom(false);
    } else {
      state.unread++;
      renderBadge();
      blip([587, 880], 0.09, 0.04);
    }
  }
  if (LOVE_RE.test(m.text) && m.from === state.me.id) heartBurst();
}
function removeMsg(id) {
  const i = state.msgs.findIndex((x) => x.id === id);
  if (i >= 0) state.msgs.splice(i, 1);
  state.msgById.delete(id);
  const node = msgsEl.querySelector(`.bubble[data-mid="${id}"]`);
  if (node) node.closest('.msg').remove();
  renderPreview();
}
function scrollBottom(force) {
  const nearBottom = msgsEl.scrollHeight - msgsEl.scrollTop - msgsEl.clientHeight < 240;
  if (force || nearBottom) msgsEl.scrollTop = msgsEl.scrollHeight;
}
async function markRead(lastId) {
  if (!lastId) return;
  state.unread = 0;
  renderBadge();
  try { await api(`/api/messages/${lastId}/read`, { body: {} }); } catch { /* ignore */ }
}

async function openChat() {
  state.chatOpen = true;
  $('#app-shell').classList.add('show-chat');
  $('#chat-row').classList.add('active');
  renderStatus();
  const data = await api('/api/messages');
  state.msgs = data.messages;
  state.msgById = new Map(data.messages.map((m) => [m.id, m]));
  state.partnerOnline = data.partnerOnline;
  if (state.partnerOnline) state.partnerLastSeen = 0;
  renderMsgs();
  renderStatus();
  const lastFromPartner = [...state.msgs].reverse().find((m) => m.from !== state.me.id);
  if (lastFromPartner) markRead(lastFromPartner.id);
  const note = state.couple && state.couple.note;
  if (note) toast(`📝 “${note}”`, 5000);
}

// ---------------- sending ----------------
async function sendMessage() {
  const inp = $('#input');
  const text = inp.value.trim();
  if (!text) return;
  inp.value = '';
  hideEmojiPop();
  state.ws && state.ws.readyState === 1 && state.ws.send(JSON.stringify({ type: 'typing', on: false }));
  try {
    const { m } = await api('/api/messages', { body: { text } });
    upsertMsg(m);
    if (LOVE_RE.test(text)) heartBurst();
  } catch (err) {
    inp.value = text;
    toast(err.message);
  }
}
$('#send-btn').onclick = sendMessage;
$('#input').addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); }
});
$('#input').addEventListener('input', () => {
  const now = Date.now();
  if ($('#input').value && now - state.lastTypingSent > 2000) {
    state.lastTypingSent = now;
    state.ws && state.ws.readyState === 1 && state.ws.send(JSON.stringify({ type: 'typing', on: true }));
  }
});

// ---------------- emoji + reactions ----------------
const pop = $('#emoji-pop');
for (const e of EMOJIS) {
  const b = el('button', null, e);
  b.type = 'button';
  b.onclick = () => { $('#input').value += e; $('#input').focus(); };
  pop.appendChild(b);
}
function hideEmojiPop() { pop.classList.add('hidden'); }
$('#emoji-btn').onclick = (e) => { e.stopPropagation(); pop.classList.toggle('hidden'); };
document.addEventListener('click', (e) => {
  if (!pop.classList.contains('hidden') && !pop.contains(e.target) && e.target.id !== 'emoji-btn') hideEmojiPop();
});

const REACT_SET = ['❤️', '😂', '😮', '😢', '🙏', '👍'];
let reactPopFor = null;
function openReactPop(bubble) {
  closeReactPop();
  const m = state.msgById.get(bubble.dataset.mid);
  if (!m) return;
  reactPopFor = m;
  const div = el('div');
  div.className = 'emoji-pop';
  div.style.position = 'fixed';
  const r = bubble.getBoundingClientRect();
  div.style.left = Math.max(8, Math.min(window.innerWidth - 260, r.left)) + 'px';
  div.style.top = Math.max(8, r.top - 58) + 'px';
  div.style.bottom = 'auto';
  div.style.gridTemplateColumns = 'repeat(6, 1fr)';
  for (const e of REACT_SET) {
    const b = el('button', null, e);
    b.type = 'button';
    b.onclick = (ev) => { ev.stopPropagation(); api(`/api/messages/${m.id}/reaction`, { body: { emoji: e } }).catch(() => {}); closeReactPop(); };
    div.appendChild(b);
  }
  const del = el('button', null, '🗑️');
  del.type = 'button';
  del.title = 'Delete for me';
  del.onclick = (ev) => { ev.stopPropagation(); api(`/api/messages/${m.id}`, { method: 'DELETE' }).catch(() => {}); closeReactPop(); };
  div.appendChild(del);
  document.body.appendChild(div);
  setTimeout(() => document.addEventListener('click', closeReactPop), 0);
}
function closeReactPop() {
  $$('.emoji-pop').forEach((p) => { if (p === document.body.lastElementChild || p.style.position === 'fixed') p.remove(); });
  $$('.emoji-pop[style]').forEach((p) => p.remove());
  pop.classList.add('hidden');
  reactPopFor = null;
}
msgsEl.addEventListener('click', (e) => {
  const bub = e.target.closest('.bubble');
  if (bub) openReactPop(bub);
});

// ---------------- realtime ----------------
function connectWS() {
  if (state.ws && (state.ws.readyState === 0 || state.ws.readyState === 1)) return;
  const proto = location.protocol === 'https:' ? 'wss' : 'ws';
  const ws = new WebSocket(`${proto}://${location.host}/ws?token=${encodeURIComponent(state.token)}`);
  state.ws = ws;
  ws.onopen = () => { state.wsRetrying = false; };
  ws.onmessage = (e) => {
    let ev;
    try { ev = JSON.parse(e.data); } catch { return; }
    handleEvent(ev);
  };
  ws.onclose = () => {
    if (!state.wsRetrying) {
      state.wsRetrying = true;
      setTimeout(connectWS, 2500);
    }
  };
  ws.onerror = () => { try { ws.close(); } catch { /* ignore */ } };
}
function handleEvent(ev) {
  switch (ev.type) {
    case 'hello':
      if (ev.partner) { state.partner = ev.partner; state.partnerOnline = ev.partnerOnline; renderSide(); renderStatus(); }
      break;
    case 'partner_joined':
      api('/api/me').then((r) => {
        state.partner = r.partner;
        state.couple = r.couple;
        toast('Your person just joined! 💘');
        heartBurst();
        renderSide();
        openChat();
      });
      break;
    case 'message':
      upsertMsg(ev.m);
      break;
    case 'typing':
      state.typing = ev.on;
      renderStatus();
      renderPreview();
      clearTimeout(state.typingTimer);
      if (ev.on) state.typingTimer = setTimeout(() => { state.typing = false; renderStatus(); renderPreview(); }, 5000);
      break;
    case 'presence':
      if (state.partner && ev.uid === state.partner.id) {
        state.partnerOnline = ev.online;
        if (!ev.online) state.partnerLastSeen = ev.ts;
        renderStatus();
      }
      break;
    case 'read':
      if (ev.by === state.partner.id) {
        for (const m of state.msgs) if (m.from === state.me.id && m.ts <= ev.upTo) m.readBy.push(ev.by);
        renderMsgsKeepScroll();
        renderPreview();
      }
      break;
    case 'reaction':
      for (const m of state.msgs) if (m.id === ev.id) { m.reactions = ev.reactions; break; }
      upsertMsg(state.msgById.get(ev.id));
      break;
    case 'deleted':
      if (ev.by === state.me.id) removeMsg(ev.id);
      else if (state.msgById.get(ev.id)) upsertMsg(state.msgById.get(ev.id));
      break;
    case 'couple_update':
      state.couple = ev.couple;
      applyWallpaper(ev.couple.wallpaper);
      renderSide();
      break;
  }
}
function renderMsgsKeepScroll() {
  const top = msgsEl.scrollTop;
  renderMsgsNoScroll();
  msgsEl.scrollTop = top;
}
function renderMsgsNoScroll() {
  const keep = msgsEl.scrollTop;
  renderMsgsCore();
  msgsEl.scrollTop = keep;
}
function renderMsgsCore() {
  msgsEl.innerHTML = '';
  let lastDay = '', prev = null;
  for (const m of state.msgs) {
    const day = fmtDay(m.ts);
    if (day !== lastDay) { msgsEl.appendChild(el('div', 'day-chip', day)); lastDay = day; prev = null; }
    msgsEl.appendChild(bubbleNode(m, prev));
    prev = m;
  }
}
function startPolling() {
  clearInterval(state.pollTimer);
  state.pollTimer = setInterval(async () => {
    if (!state.couple) return;
    try {
      const data = await api('/api/messages');
      state.partnerOnline = data.partnerOnline;
      let changed = false;
      for (const m of data.messages) {
        const ex = state.msgById.get(m.id);
        if (!ex) { upsertMsg(m, { silent: true }); changed = true; }
        else if (ex.delivered !== m.delivered || JSON.stringify(ex.readBy) !== JSON.stringify(m.readBy)) { Object.assign(ex, m); changed = true; }
      }
      if (changed) renderMsgsKeepScroll();
      renderStatus();
    } catch { /* offline — keep trying */ }
  }, 5000);
}

// ---------------- memory lane ----------------
function maybeMemoryLane() {
  if (state.msgs.length < 3) return;
  const now = new Date();
  let pick = state.msgs.find((m) => {
    const d = new Date(m.ts);
    return d.getMonth() === now.getMonth() && d.getDate() === now.getDate() && Date.now() - m.ts > 30 * 86400000;
  });
  if (!pick) {
    const old = state.msgs.filter((m) => Date.now() - m.ts > 7 * 86400000);
    pick = old[Math.floor(Math.random() * old.length)];
  }
  if (!pick) return;
  const key = now.toISOString().slice(0, 10);
  if (state.lastMemoryShown === key + pick.id) return;
  state.lastMemoryShown = key + pick.id;
  localStorage.setItem('lc_memory', state.lastMemoryShown);
  const mine = pick.from === state.me.id;
  const b = el('b', null, '🕰 Memory Lane');
  const t = el('div', 'mem-text', `“${pick.text}”`);
  const sub = el('div', 'mem-sub', `${mine ? 'You said' : `${state.partner.name} said`} this on ${shortDayFmt.format(new Date(pick.ts))} — tap to relive it`);
  const box = el('div');
  box.appendChild(b); box.appendChild(t); box.appendChild(sub);
  box.onclick = () => {
    box.remove();
    const node = msgsEl.querySelector(`.bubble[data-mid="${pick.id}"]`);
    if (node) { node.scrollIntoView({ behavior: 'smooth', block: 'center' }); node.classList.add('flash'); setTimeout(() => node.classList.remove('flash'), 1700); }
  };
  msgsEl.parentElement.appendChild(box);
  setTimeout(() => box.remove(), 9000);
}

// ---------------- settings / stats ----------------
function applyWallpaper(wp) {
  msgsEl.className = 'msgs wp-' + (WALLPAPER_CHECK(wp) ? wp : 'classic');
  $$('.wp-swp').forEach((b) => b.classList.toggle('sel', b.dataset.wp === wp));
}
const WALLPAPER_OK = ['classic', 'rose', 'night', 'ocean'];
function WALLPAPER_CHECK(w) { return WALLPAPER_OK.includes(w); }
function applyTheme() {
  document.documentElement.classList.toggle('dark', localStorage.getItem('lc_dark') === 'on');
  $('#set-dark').checked = localStorage.getItem('lc_dark') === 'on';
  $('#set-sound').checked = soundOn();
}
function openSettings() {
  const s = state.couple ? new Date(state.couple.startTs) : new Date();
  $('#set-start').value = `${s.getFullYear()}-${String(s.getMonth() + 1).padStart(2, '0')}-${String(s.getDate()).padStart(2, '0')}`;
  $('#set-note').value = state.couple ? state.couple.note : '';
  applyWallpaper(state.couple ? state.couple.wallpaper : 'classic');
  $('#modal-settings').classList.remove('hidden');
}
$$('.wp-swp').forEach((b) => (b.onclick = () => $$('.wp-swp').forEach((x) => x.classList.toggle('sel', x === b))));
$('#set-dark').onchange = (e) => {
  localStorage.setItem('lc_dark', e.target.checked ? 'on' : 'off');
  document.documentElement.classList.toggle('dark', e.target.checked);
};
$('#set-sound').onchange = (e) => localStorage.setItem('lc_sound', e.target.checked ? 'on' : 'off');
$('#set-save').onclick = async () => {
  const body = {
    note: $('#set-note').value,
    wallpaper: ($('.wp-swp.sel') || {}).dataset ? $('.wp-swp.sel').dataset.wp : 'classic',
  };
  const sv = $('#set-start').value;
  if (sv) body.startTs = new Date(sv + 'T12:00:00').getTime();
  try {
    const r = await api('/api/couple', { method: 'PATCH', body });
    state.couple = r.couple;
    $('#modal-settings').classList.add('hidden');
    toast('Saved 💾');
    renderSide();
  } catch (err) { toast(err.message); }
};
function openStats() {
  $('#stat-days').textContent = daysTogether();
  $('#stat-anniv').textContent = anniversaryText();
  $('#stat-msgs').textContent = state.msgs.length;
  const loveCount = state.msgs.filter((m) => m.from === state.me.id && /love/i.test(m.text)).length;
  $('#stat-love').textContent = loveCount;
  const lv = loveLevel();
  $('#stat-levelbar').style.width = Math.min(100, lv.pct) + '%';
  $('#stat-levelname').textContent = `${lv.lvl} · ${lv.name}`;
  const first = state.msgs[0];
  $('#stat-first').textContent = first ? `“${first.text}” — ${shortDayFmt.format(new Date(first.ts))}` : 'No messages yet — say hi! 💌';
  $('#stat-note').textContent = state.couple && state.couple.note ? `“${state.couple.note}”` : 'No note yet — add one in settings 💌';
  $('#modal-stats').classList.remove('hidden');
}
$('#tb-stats').onclick = openStats;
$('#tb-settings').onclick = openSettings;
$$('.modal').forEach((m) => {
  m.addEventListener('click', (e) => { if (e.target === m) m.classList.add('hidden'); });
});
$$('[data-close]').forEach((b) => (b.onclick = () => $('#' + b.dataset.close).classList.add('hidden')));
$('#call-btn').onclick = () => toast('Let’s keep it a little mysterious — calls are coming soon 📞💙');
$('#video-btn').onclick = () => toast('Let’s keep it a little mysterious — video is coming soon 🎥💙');
$('#back-btn').onclick = () => {
  $('#app-shell').classList.remove('show-chat');
  state.chatOpen = false;
  $('#chat-row').classList.remove('active');
};
$('#chat-row').onclick = () => {
  if (!chatVisible()) openChat();
};
async function doLogout() {
  try { await api('/api/logout', { body: {} }); } catch { /* ignore */ }
  localStorage.removeItem('lc_token');
  location.reload();
}
$('#tb-logout').onclick = doLogout;

// keep "last seen" fresh
setInterval(renderStatus, 30000);
setInterval(() => { if (state.couple) $('#days-pill').textContent = `💞 ${daysTogether()} day${daysTogether() > 1 ? 's' : ''} of us · anniversary ${anniversaryText()}`; }, 60000);

// ---------------- init ----------------
(function init() {
  // pending invite from share link
  const q = new URLSearchParams(location.search).get('invite');
  if (q) {
    localStorage.setItem('lc_invite', q.toUpperCase());
    state.pendingInvite = q.toUpperCase();
    history.replaceState({}, '', location.pathname);
  }
  $('#invite-banner').classList.toggle('hidden', !state.pendingInvite);
  if (state.pendingInvite) setTab('signup');
  applyTheme();

  if (state.token) {
    api('/api/me')
      .then(async (r) => {
        state.me = r.me;
        if (r.couple) {
          localStorage.removeItem('lc_invite');
          state.pendingInvite = null;
          await startApp();
        } else if (state.pendingInvite) {
          // logged in, but the link was for us — offer to accept on waiting screen
          await showWaiting();
        } else {
          await showWaiting();
        }
      })
      .catch(() => {
        localStorage.removeItem('lc_token');
        state.token = null;
        show('auth');
      });
  } else {
    show('auth');
  }
})();
