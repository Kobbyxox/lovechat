#!/usr/bin/env node
/* LoveChat — a WhatsApp-style private chat for couples.
   Single Node server: REST (auth, messages, couple settings) + WebSocket (realtime).
   Data persists to data/db.json (simple JSON store). */
'use strict';

const http = require('http');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const express = require('express');
const { WebSocketServer } = require('ws');

const PORT = process.env.PORT || 8080;
const DATA_DIR = path.join(__dirname, 'data');
const DATA = path.join(DATA_DIR, 'db.json');
const WALLPAPERS = ['classic', 'rose', 'night', 'ocean'];

let db = { users: {}, couples: {}, messages: {}, tokens: {} };
try {
  if (fs.existsSync(DATA)) {
    const loaded = JSON.parse(fs.readFileSync(DATA, 'utf8'));
    db = Object.assign(db, loaded);
  }
} catch (e) {
  console.error('db load failed, starting fresh:', e.message);
}

let saveTimer = null;
function save() {
  if (saveTimer) return;
  saveTimer = setTimeout(() => {
    saveTimer = null;
    try {
      fs.mkdirSync(DATA_DIR, { recursive: true });
      fs.writeFileSync(DATA, JSON.stringify(db));
    } catch (e) {
      console.error('db save failed:', e.message);
    }
  }, 150);
}

// ---------------- helpers ----------------
const id = () => crypto.randomBytes(9).toString('hex');
const CODE_CHARS = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
const invCode = () =>
  Array.from({ length: 6 }, () => CODE_CHARS[crypto.randomInt(CODE_CHARS.length)]).join('');
const hashPw = (pw, salt) => crypto.scryptSync(String(pw), salt, 32).toString('hex');
const verifyPw = (pw, salt, hash) => {
  const h = Buffer.from(hashPw(pw, salt), 'hex');
  const g = Buffer.from(hash, 'hex');
  return h.length === g.length && crypto.timingSafeEqual(h, g);
};
function newToken(uid) {
  const t = crypto.randomBytes(24).toString('hex');
  db.tokens[t] = uid;
  save();
  return t;
}
function dropToken(t) {
  delete db.tokens[t];
  save();
}
function authed(req) {
  const h = req.headers.authorization || '';
  const t = h.startsWith('Bearer ') ? h.slice(7) : null;
  const uid = t && db.tokens[t];
  return t && uid ? { token: t, uid } : null;
}
function pub(u) {
  if (!u) return null;
  return {
    id: u.id, name: u.name, email: u.email, inviteCode: u.inviteCode,
    partnerId: u.partnerId || null, lastSeen: u.lastSeen || 0, createdAt: u.createdAt,
  };
}
function coupleOf(uid) {
  for (const c of Object.values(db.couples)) if (c.a === uid || c.b === uid) return c;
  return null;
}
function partnerOf(uid) {
  const u = db.users[uid];
  return u && u.partnerId ? db.users[u.partnerId] : null;
}
const msgs = (cid) => (db.messages[cid] ||= []);

// naive rate limit (per IP, per 10 min)
const hits = new Map();
function limited(req, limit = 60) {
  const ip = req.ip || '?';
  const now = Date.now();
  const rec = hits.get(ip) || { n: 0, t: now };
  if (now - rec.t > 10 * 60 * 1000) { rec.n = 0; rec.t = now; }
  rec.n++;
  hits.set(ip, rec);
  return rec.n > limit;
}

// ---------------- REST ----------------
const APP = express();
APP.use(express.json({ limit: '64kb' }));
APP.use(express.static(path.join(__dirname, 'public')));
APP.use((err, req, res, next) => {
  if (err && err.type === 'entity.parse.failed') return res.status(400).json({ error: 'Bad request.' });
  next(err);
});

function tryAcceptInvite(uid, code) {
  const me = db.users[uid];
  if (me.partnerId) return { error: 'You already have a partner in your LoveChat.' };
  const other = Object.values(db.users).find((u) => u.inviteCode === String(code || '').trim().toUpperCase());
  if (!other || other.id === uid) return { error: 'That invite link is not valid.' };
  if (other.partnerId) return { error: 'That invite was already used.' };
  const c = { id: id(), a: uid, b: other.id, startTs: Date.now(), wallpaper: 'classic', note: '', createdAt: Date.now() };
  db.couples[c.id] = c;
  me.partnerId = other.id;
  other.partnerId = uid;
  save();
  broadcastCouple(c.id, { type: 'partner_joined' }, null);
  return { couple: c };
}

APP.post('/api/signup', (req, res) => {
  if (limited(req, 30)) return res.status(429).json({ error: 'Too many attempts, slow down a little. 💙' });
  const { email, password, name, invite } = req.body || {};
  const em = String(email || '').trim().toLowerCase();
  const nm = String(name || '').trim();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(em)) return res.status(400).json({ error: 'Please enter a valid email.' });
  if (String(password || '').length < 6) return res.status(400).json({ error: 'Password needs at least 6 characters.' });
  if (nm.length < 2 || nm.length > 40) return res.status(400).json({ error: 'Please enter your name (2–40 characters).' });
  if (Object.values(db.users).some((u) => u.email === em))
    return res.status(409).json({ error: 'An account with this email already exists — try signing in.' });
  const salt = crypto.randomBytes(16).toString('hex');
  const u = {
    id: id(), email: em, name: nm,
    pass: { salt, hash: hashPw(password, salt) },
    inviteCode: invCode(), partnerId: null, lastSeen: Date.now(), createdAt: Date.now(),
  };
  db.users[u.id] = u;
  save();
  const token = newToken(u.id);
  let couple = null;
  if (invite) {
    const r = tryAcceptInvite(u.id, invite);
    if (r.couple) couple = r.couple;
  }
  res.json({ token, me: pub(u), couple: couple || null });
});

APP.post('/api/login', (req, res) => {
  if (limited(req, 40)) return res.status(429).json({ error: 'Too many attempts, slow down a little. 💙' });
  const { email, password } = req.body || {};
  const u = Object.values(db.users).find((x) => x.email === String(email || '').trim().toLowerCase());
  if (!u || !verifyPw(password, u.pass.salt, u.pass.hash))
    return res.status(401).json({ error: 'Wrong email or password.' });
  res.json({ token: newToken(u.id), me: pub(u), couple: coupleOf(u.id) || null });
});

APP.post('/api/logout', (req, res) => {
  const a = authed(req);
  if (a) dropToken(a.token);
  res.json({ ok: true });
});

APP.get('/api/me', (req, res) => {
  const a = authed(req);
  if (!a) return res.status(401).json({ error: 'Not signed in.' });
  const u = db.users[a.uid];
  res.json({ me: pub(u), partner: pub(partnerOf(u.id)), couple: coupleOf(u.id) || null });
});

APP.get('/api/couple', (req, res) => {
  const a = authed(req);
  if (!a) return res.status(401).json({ error: 'Not signed in.' });
  const c = coupleOf(a.uid);
  if (!c) return res.json({ couple: null, partner: null, unread: 0, partnerOnline: false });
  const p = partnerOf(a.uid);
  const unread = msgs(c.id).filter(
    (m) => m.from !== a.uid && !m.deletedFor.includes(a.uid) && !m.readBy.includes(a.uid)
  ).length;
  res.json({ couple: c, partner: pub(p), unread, partnerOnline: online(p ? p.id : null) });
});

APP.patch('/api/couple', (req, res) => {
  const a = authed(req);
  if (!a) return res.status(401).json({ error: 'Not signed in.' });
  const c = coupleOf(a.uid);
  if (!c) return res.status(400).json({ error: 'No couple yet.' });
  const { startTs, wallpaper, note } = req.body || {};
  if (startTs != null) {
    const n = Number(startTs);
    if (Number.isFinite(n) && n > 0 && n < Date.now()) c.startTs = Math.floor(n);
  }
  if (wallpaper != null && WALLPAPERS.includes(wallpaper)) c.wallpaper = wallpaper;
  if (note != null) c.note = String(note).slice(0, 500);
  save();
  broadcastCouple(c.id, { type: 'couple_update', couple: c }, a.uid);
  res.json({ couple: c });
});

APP.get('/api/messages', (req, res) => {
  const a = authed(req);
  if (!a) return res.status(401).json({ error: 'Not signed in.' });
  const c = coupleOf(a.uid);
  if (!c) return res.json({ messages: [], partnerOnline: false });
  const p = partnerOf(a.uid);
  const list = msgs(c.id).filter((m) => !m.deletedFor.includes(a.uid)).slice(-200);
  res.json({ messages: list, partnerOnline: online(p ? p.id : null) });
});

APP.post('/api/messages', (req, res) => {
  const a = authed(req);
  if (!a) return res.status(401).json({ error: 'Not signed in.' });
  const c = coupleOf(a.uid);
  if (!c) return res.status(400).json({ error: 'Invite your partner first.' });
  const text = String((req.body || {}).text || '').trim();
  if (!text) return res.status(400).json({ error: 'Nothing to send.' });
  if (text.length > 2000) return res.status(400).json({ error: 'Message too long (max 2000).' });
  const p = partnerOf(a.uid);
  const m = {
    id: id(), from: a.uid, text, ts: Date.now(),
    delivered: online(p ? p.id : null),
    readBy: [a.uid], reactions: {}, deletedFor: [],
  };
  msgs(c.id).push(m);
  save();
  broadcastCouple(c.id, { type: 'message', m }, null);
  res.json({ m });
});

APP.post('/api/messages/:id/read', (req, res) => {
  const a = authed(req);
  if (!a) return res.status(401).json({ error: 'Not signed in.' });
  const c = coupleOf(a.uid);
  if (!c) return res.json({ ok: true });
  const target = msgs(c.id).find((m) => m.id === req.params.id);
  if (!target) return res.json({ ok: true });
  let changed = false;
  for (const m of msgs(c.id)) {
    if (m.from !== a.uid && m.ts <= target.ts && !m.readBy.includes(a.uid)) {
      m.readBy.push(a.uid);
      changed = true;
    }
  }
  if (changed) {
    save();
    broadcastCouple(c.id, { type: 'read', by: a.uid, upTo: target.ts }, a.uid);
  }
  res.json({ ok: true });
});

APP.post('/api/messages/:id/reaction', (req, res) => {
  const a = authed(req);
  if (!a) return res.status(401).json({ error: 'Not signed in.' });
  const c = coupleOf(a.uid);
  if (!c) return res.json({ ok: true });
  const m = msgs(c.id).find((x) => x.id === req.params.id);
  const emoji = String((req.body || {}).emoji || '');
  if (!m || !/^(\p{Extended_Pictographic}|\uFE0F|\u200D|\u20E3)+$/u.test(emoji) || emoji.length > 8)
    return res.status(400).json({ error: 'Bad reaction.' });
  const arr = (m.reactions[emoji] ||= []);
  const i = arr.indexOf(a.uid);
  if (i >= 0) arr.splice(i, 1);
  else arr.push(a.uid);
  if (!arr.length) delete m.reactions[emoji];
  save();
  broadcastCouple(c.id, { type: 'reaction', id: m.id, reactions: m.reactions, by: a.uid }, null);
  res.json({ ok: true });
});

APP.delete('/api/messages/:id', (req, res) => {
  const a = authed(req);
  if (!a) return res.status(401).json({ error: 'Not signed in.' });
  const c = coupleOf(a.uid);
  if (!c) return res.json({ ok: true });
  const m = msgs(c.id).find((x) => x.id === req.params.id);
  if (m) {
    if (!m.deletedFor.includes(a.uid)) m.deletedFor.push(a.uid);
    save();
    broadcastCouple(c.id, { type: 'deleted', id: m.id, by: a.uid }, null);
  }
  res.json({ ok: true });
});

APP.post('/api/invite', (req, res) => {
  const a = authed(req);
  if (!a) return res.status(401).json({ error: 'Not signed in.' });
  const r = tryAcceptInvite(a.uid, (req.body || {}).code);
  if (r.error) return res.status(400).json(r);
  res.json(r);
});

// ---------------- realtime ----------------
const server = http.createServer(APP);
const wss = new WebSocketServer({ server, path: '/ws' });
const sockets = new Map(); // userId -> Set<ws>

const online = (uid) => {
  const s = uid && sockets.get(uid);
  return !!(s && s.size);
};
function send(ws, obj) {
  if (ws.readyState === 1) ws.send(JSON.stringify(obj));
}
function broadcastCouple(cid, obj, exceptUid) {
  const c = db.couples[cid];
  if (!c) return;
  for (const uid of [c.a, c.b]) {
    if (uid === exceptUid) continue;
    for (const ws of sockets.get(uid) || []) send(ws, obj);
  }
}

wss.on('connection', (ws, req) => {
  const url = new URL(req.url, 'http://localhost');
  const uid = db.tokens[url.searchParams.get('token') || ''];
  if (!uid) {
    ws.close();
    return;
  }
  ws.uid = uid;
  ws.isAlive = true;
  let set = sockets.get(uid);
  if (!set) {
    set = new Set();
    sockets.set(uid, set);
  }
  set.add(ws);
  db.users[uid].lastSeen = Date.now();
  save();
  const c = coupleOf(uid);
  const p = partnerOf(uid);
  send(ws, {
    type: 'hello',
    me: pub(db.users[uid]),
    partner: pub(p),
    partnerOnline: p ? online(p.id) : false,
    couple: c || null,
  });
  if (c) broadcastCouple(c.id, { type: 'presence', uid, online: true, ts: Date.now() }, uid);
  ws.on('pong', () => { ws.isAlive = true; });
  ws.on('message', (raw) => {
    let data;
    try { data = JSON.parse(raw); } catch { return; }
    if (data && data.type === 'typing') {
      const cc = coupleOf(uid);
      if (cc) broadcastCouple(cc.id, { type: 'typing', uid, on: !!data.on }, uid);
    }
  });
  ws.on('close', () => {
    const s = sockets.get(uid);
    if (s) {
      s.delete(ws);
      if (!s.size) sockets.delete(uid);
    }
    db.users[uid].lastSeen = Date.now();
    save();
    const c2 = coupleOf(uid);
    if (c2) broadcastCouple(c2.id, { type: 'presence', uid, online: false, ts: Date.now() }, uid);
  });
});

wss.on('error', (e) => console.error('ws error:', e.message));
process.on('uncaughtException', (e) => console.error('uncaught:', e.message));

setInterval(() => {
  for (const set of sockets.values()) {
    for (const ws of set) {
      if (!ws.isAlive) { ws.terminate(); continue; }
      ws.isAlive = false;
      try { ws.ping(); } catch { /* ignore */ }
    }
  }
}, 30000);

server.listen(PORT, '0.0.0.0', () => {
  console.log(`LoveChat running on http://0.0.0.0:${PORT}`);
});
